package com.tour.response;

import com.tour.pojo.PackageSuggestPojo;

public class PackageSuggestPojoResponse extends AbstractPojoResponse{
	
	PackageSuggestPojo packageSuggestPojo;

	public PackageSuggestPojo getPackageSuggestPojo() {
		return packageSuggestPojo;
	}

	public void setPackageSuggestPojo(PackageSuggestPojo packageSuggestPojo) {
		this.packageSuggestPojo = packageSuggestPojo;
	}
	
	

}
