package com.tour.response;

import java.util.List;

import com.tour.pojo.PlacePojo;



public class PlaceListResponse {

	List<PlacePojo> placePojos;

	public List<PlacePojo> getPlacePojos() {
		return placePojos;
	}

	public void setPlacePojos(List<PlacePojo> placePojos) {
		this.placePojos = placePojos;
	}
}
