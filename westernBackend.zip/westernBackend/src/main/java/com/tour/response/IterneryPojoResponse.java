package com.tour.response;

import com.tour.pojo.IterneryPojo;

public class IterneryPojoResponse  extends AbstractPojoResponse{
	public IterneryPojo iterneryPojo;

	public IterneryPojo getIterneryPojo() {
		return iterneryPojo;
	}

	public void setIterneryPojo(IterneryPojo iterneryPojo) {
		this.iterneryPojo = iterneryPojo;
	}

}