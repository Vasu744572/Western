package com.tour.response;

import com.tour.pojo.SeasonPojo;

public class SeasonPojoResponse extends AbstractPojoResponse{
	SeasonPojo seasonPojo;

	public SeasonPojo getSeasonPojo() {
		return seasonPojo;
	}

	public void setSeasonPojo(SeasonPojo seasonPojo) {
		this.seasonPojo = seasonPojo;
	}
	

}
