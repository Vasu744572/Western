package com.tour.response;

import java.util.List;

import com.tour.pojo.ThemePojo;

public class ThemeListResponse {

List<ThemePojo> themePojo;

public List<ThemePojo> getThemePojo() {
	return themePojo;
}

public void setThemePojo(List<ThemePojo> themePojo) {
	this.themePojo = themePojo;
}

	
}
