package com.tour.response;

import com.tour.pojo.TourpackagePojo;

public class TourpackageResponse {
	TourpackagePojo tourpackagePojo;

	public TourpackagePojo getTourpackagePojo() {
		return tourpackagePojo;
	}

	public void setTourpackagePojo(TourpackagePojo tourpackagePojo) {
		this.tourpackagePojo = tourpackagePojo;
	}
	

}
