package com.tour.response;

public class PackageIdResponse {
	long tourpackageID;

	public long getTourpackagePojo() {
		return tourpackageID;
	}

	public void setTourpackagePojo(long PackageId) {
		this.tourpackageID = PackageId;
	}
}
