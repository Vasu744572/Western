package com.tour.response;

import com.tour.pojo.ThemePojo;

public class ThemeResponse {
	
	ThemePojo themePojo;

	public ThemePojo getThemePojo() {
		return themePojo;
	}

	public void setThemePojo(ThemePojo themePojo) {
		this.themePojo = themePojo;
	}

}
