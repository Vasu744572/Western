package com.tour.pojo;

import java.util.List;

public class TourPackageIterneryPojo {

	private long id;
	private List<IterneryPojo> iterneries;
	
	public long getId() {
		return id;
	}
	public void setId(long id) {
		this.id = id;
	}
	public List<IterneryPojo> getIterneries() {
		return iterneries;
	}
	public void setIterneries(List<IterneryPojo> iterneries) {
		this.iterneries = iterneries;
	}
	
	
	
	
}
