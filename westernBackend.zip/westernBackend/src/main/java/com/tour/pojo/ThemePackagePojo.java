package com.tour.pojo;

public class ThemePackagePojo {
	private long id;

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}



}
