package com.tour.facade;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;
import org.springframework.util.ObjectUtils;

import com.tour.entity.Asset;
import com.tour.entity.Iternery;
import com.tour.pojo.IterneryPojo;
import com.tour.response.IterneryPojoListResponse;
import com.tour.response.IterneryPojoResponse;
import com.tour.response.ResponseMessagePojo;
import com.tour.service.AssetService;
import com.tour.service.IterneryService;
import com.tour.util.ObjectMapperUtils;

@Component
public class IterneryFacade {

	@Autowired
	IterneryService iterneryService;
	
	@Autowired
	AssetService assetService;

	public IterneryPojoResponse create(IterneryPojo iterneryPojo) {
		Iternery iternery = ObjectMapperUtils.map(iterneryPojo, Iternery.class);
		List<Asset> asset=ObjectMapperUtils.mapAll(iterneryPojo.getImages(), Asset.class);
		Asset savedAsset=new Asset();
		for (Asset eachAsset : asset) {
			savedAsset=	assetService.saveAsset(eachAsset);
		}
		if (!ObjectUtils.isEmpty(savedAsset)) {
			Set<Asset> assetSet=new HashSet<Asset>();
			assetSet.add(savedAsset);
			iternery.setImages(assetSet);
		}
		iternery = iterneryService.create(iternery);
		iterneryPojo = ObjectMapperUtils.map(iternery, IterneryPojo.class);
		return CreateDeleteUpdateResponse(iterneryPojo, "createdSuccessfully");
	}

	private IterneryPojoResponse CreateDeleteUpdateResponse(IterneryPojo iterneryPojo, String message) {
		IterneryPojoResponse iterneryPojoResponse = new IterneryPojoResponse();
		List<ResponseMessagePojo> successMessaages = new ArrayList<ResponseMessagePojo>();
		ResponseMessagePojo responseMessagePojo = new ResponseMessagePojo();
		responseMessagePojo.setStatus(HttpStatus.OK);
		responseMessagePojo.setSuccessMessage(message);
		successMessaages.add(responseMessagePojo);
		iterneryPojoResponse.setSuccessMessaages(successMessaages);
		return iterneryPojoResponse;
	}

	public IterneryPojoListResponse getAll() {
		IterneryPojoListResponse iterneryPojoListResponse = new IterneryPojoListResponse();
		List<Iternery> iterneryList = iterneryService.getAll();
		List<IterneryPojo> iterneryPojoList = ObjectMapperUtils.mapAll(iterneryList, IterneryPojo.class);
		iterneryPojoListResponse.setIterneryListPojo(iterneryPojoList);
		return iterneryPojoListResponse;
	}

	public IterneryPojoResponse update(IterneryPojo iterneryPojo) {
		Iternery iternery = iterneryService.findIterneryById(iterneryPojo.getId());
		ObjectMapperUtils.map(iterneryPojo, iternery);
		iternery = iterneryService.update(iternery);
		iterneryPojo=ObjectMapperUtils.map(iternery,IterneryPojo.class);
		return CreateDeleteUpdateResponse(iterneryPojo,"Updated Successfully");
	}

	public IterneryPojoResponse delete(long id) {
		Iternery iternery=iterneryService.findIterneryById(id);
		iterneryService.delete(iternery);
		return CreateDeleteUpdateResponse(null,"Deleted Successfully");
	}
}
